-- Overview --

A field formatter for the image field to add Bootstrap carousel.

-- Requirements --

A bootstrap theme.

-- Installing --

Enable the module.
You should now have available a Bootstrap Carousel image field formatter.

-- Overriding output --

override the theme_bootstrap_carousel_if($vars) function.
