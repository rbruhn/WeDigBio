Description
===========
Elements intends to become a library that provides complex form elements for developers to use in their modules.


Elements provided
=================

1. emailfield
2. searchfield
3. telfield
4. urlfield
5. numberfield
6. rangefield
