<?php
/**
 * @file
 * Single menu container.
 */
?>
<div class="<?php print $class; ?>"><?php print render($menu_output); ?></div>
