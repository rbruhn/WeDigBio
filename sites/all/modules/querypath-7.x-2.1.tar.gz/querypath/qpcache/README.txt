This module provides caching services for QueryPath.

It is based on code originally found in qpservices.
