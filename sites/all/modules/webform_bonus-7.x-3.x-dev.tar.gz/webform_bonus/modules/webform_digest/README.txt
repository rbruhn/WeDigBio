For correct work of Webform Digest module, please apply webform.patch to the Webform module.
